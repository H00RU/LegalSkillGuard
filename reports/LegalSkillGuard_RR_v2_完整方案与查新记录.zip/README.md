# LegalSkillGuard RR v2 研究设计交付包

2026-11-05，GitHub发布版。定稿范围为两项方法、文献差异、实现接口和有限后续验证协议。本次文档发布没有运行研究模型或服务器实验；服务器goal完成实现、离线检查、thinking实测与固定20来源流程小试后停止。

优先阅读 `LegalSkillGuard_RR_v2_完整研究方案.docx`，或内容相同的 `legalskillguard_rule_reasoning_plan_v2_20261105.md`。`legalskillguard_rule_reasoning_protocol_v2.json`保持正式run_enabled=false；独立preflight入口允许executor≤100、teacher≤2的有限实测，失败/重试计入原账且仅使用既有资源授权。当前实施范围与可粘贴/goal指令见 `legalskillguard_server_handoff_v2.md`。

方法A为“覆盖感知的部分规则编译”，方法B为“碰撞见证驱动的技能接口细化”。本版替代旧LSG-RR-v1的研究方法建议和冲突交接；发布目录为GitHub的reports，旧v1保留并标注已替代。历史代码、论文和结果保留。

`researchwrite/legalskillguard_rr_v2/`包含论证基础、最近邻专项阅读和独立交叉审查。专项报告是设计形成过程中的技术记录，部分暂名、早期预算或审查意见可能已被整合修订；出现差异时，以本包主稿、JSON协议及该目录的`qa_logs/final_closure.md`为准。内部评审分数不是学术新颖性认证或效果证明。

首轮后续协议固定五个基准、128训练来源、各8开发和32测试来源、一次8批建库。六臂是共享一次训练材料的冻结推理对照，不是六次完整重训。具体预算、强基线、停止条件和thinking判据见主稿。

`manifest_sha256.json`用于检查文件一致性。交付包不含临时脚本、研究数据、模型结果或自动执行入口。
