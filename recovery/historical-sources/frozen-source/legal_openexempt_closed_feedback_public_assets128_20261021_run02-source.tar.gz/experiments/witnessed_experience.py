"""Chronological case-backed skill evolution with exact historical evidence memory.

Reuses the original native model, ordinary tool, publication and scorer. This is
an experimental entrypoint, not a second runtime service or an answer adapter.
"""
from __future__ import annotations

import copy
import fcntl
import json
import sys
import traceback
from pathlib import Path

from experiments.decision_evidence_transfer import (
    EDIT_FEEDBACK_METHOD,
    RankedOnline,
    evidence_proposals,
)
from legal_skill_guard.experiment.storage import RunStore
from legal_skill_guard.learning.catalog import encode_teacher_body
from legal_skill_guard.learning.decision_evidence import (
    materialize_witness_skills,
    training_nonmember_catalog,
    training_witness_catalog,
    witness_knowledge_view,
    witness_membership_example,
    witnessed_guidance_schema,
    witnessed_skill_payload,
)
from legal_skill_guard.learning.experiment import ROOT, now, points, read, sha
from legal_skill_guard.learning.member_contract import annotated_sources
from legal_skill_guard.learning.member_learning import paired_effect
from legal_skill_guard.learning.packing import expand, keyed, table
from legal_skill_guard.learning.publication import (
    apply_differential_publication,
    differential_schema,
    publication_statistics,
)
from legal_skill_guard.utils.hashing import canonical_json_sha256 as csha

TEACHER_SYSTEM = (
    "Learn reusable legal inspection skills backed by selected ORIGINAL historical TRAIN evidence "
    "demonstrations. This replaces rules-only memory, not the task or frozen lawyer. Every inference "
    "remains ONE frozen8B native reason/choice/original-integer-SPAN answer on the full current NDA "
    "and same ordinary tool. Use actual supplied sources, Gold, answers and candidate observations, "
    "including successes and harms. Old reference policies are identified historical versions, NOT "
    "invented executions of this new representation. Their prose and labels are fallible experience, "
    "not universal law. Publish explicit CREATE/UPDATE/DELETE/MERGE/NOOP against current_parent_library; "
    "unmentioned records stay verbatim. Each guidance has procedure, witness_refs and nonmember_refs. A witness_ref "
    "selects an eligible already-seen source/hypothesis pair WITHIN the skill's public scope. The host "
    "materializes ALL original evidence texts. A nonmember_ref selects a REAL extra citation from "
    "a supplied past originally non-neutral task, together with that task's COMPLETE correct evidence. "
    "The exact original quotation and membership come from actual observations, not a new legal judge. "
    "Original E/C/NM labels remain available to YOU for training and audit, but past-case NLI labels "
    "are NOT delivered as lawyer examples. Runtime examples teach annotated members and an optional "
    "unannotated actual citation, not an NLI answer prior. Unannotated does not mean legally false "
    "or universally forbidden, and a local excerpt cannot establish whole-contract NM. "
    "These are different past examples, not current facts or answers. "
    "NM deliberately has no snippet demonstration: a local excerpt cannot prove whole-contract absence. "
    "Use concrete legal contrasts and source functions to teach actor/action/object, modality, "
    "quantifiers, prohibitions, triggers, exceptions and complete responsive evidence. Preserve "
    "opposed boundaries rather than treating every restriction as NM. Lack of a matching example "
    "never implies a legal label. Avoid arbitrary literal shortcuts and generalizing one phrasing. "
    "Distill source-observable relation checks from the supplied full training labels into procedures, "
    "but never infer opposition just because a permission was not found or vice versa. "
    "Choose informative historical member/nonmember contrasts and selection boundaries; "
    "do not force a fixed skill/witness count, growth, one-per-hypothesis or positive-label-only list. "
    "Both reference lists may be empty when justified; do not force signed examples or a quota. "
    "No case answer tables, IDs, original indices, "
    "parties or dates in procedures. Exact past text is supplied by reference only. Same-source "
    "member AND nonmember examples are excluded by source identity AND content hash, even for training reanswers. "
    "All original current indices remain selectable; only the lawyer decides final labels/citations. "
    "Use the REAL supplied policy differences; do not invent comparisons or missing ablation arms. "
    "candidate_contexts stores exact actual source-reading inputs once; observation context references "
    "resolve to those same complete inputs without omitted candidates or scores. Original three-way "
    "accuracy, Gold-NN hard original-SPAN F1 and strict joint are unchanged. The actual lawyer system "
    "instructions, visible output contract and exact common native schema are supplied in "
    "lawyer_task_contracts; observation references identify what was REALLY executed. Follow that "
    "task, not a different legal-brief-writing objective. The target is COMPLETE original evidence "
    "membership, NOT the smallest sufficient proof. Independently responsive repeated provisions, "
    "definitions, introductions or qualifications can be separate original members; do not exclude "
    "them categorically as repetition, recitals or context. Conversely, adjacency or usefulness for "
    "reading alone never establishes membership. Learn both inclusion and exclusion conditions "
    "from the actual original members, missed_original_members and extra_actual_citations, each "
    "resolved to exact original text. Their counts and differences are the existing benchmark "
    "feedback, not a new semantic judge. Gold-NN evidence scoring includes ALL originally non-neutral "
    "queries even when the lawyer predicts the wrong relation or NotMentioned; label changes cannot "
    "make missed evidence disappear. Preserve supported/opposed relations while repairing partial "
    "evidence, and distinguish classification errors, missing members and extra citations. Do not "
    "mistake shorter answers, fewer citations, or NM gains alone for learned evidence acquisition. "
    "A reusable skill must provide observable source selection conditions, not 'cite the Gold' or "
    "a historical case answer. The COMPLETE MATERIALIZED "
    "knowledge bank, INCLUDING every procedure/scope, ALL positive evidence texts and complete false-citation "
    "contrasts, must fit4096 "
    "actual target8B tokens; aim2800. Internal audit hashes/IDs are stored/reported separately, not served "
    "knowledge. Each eligible example's exact standalone target8B token cost is supplied. These costs "
    "guide packing, not a promise of additive BPE costs; leave room for rules/structure. Reference IDs "
    "are NOT cheap substitutes for full texts. Do not "
    "blindly attach many long examples. No per-record character clipping or fixed template quota. "
    "All structurally valid edits publish without utility admission, best-bank selection, score-based "
    "retry, fallback or a second curator. Explain the actual source-supported change for each "
    "operation; do not invent successful execution or expose hidden reasoning. No tools/outside data. "
    "Return the exact differential JSON schema."
)


REFLECTION_SYSTEM = (
    "Analyze the ACTUAL public answers of a frozen legal model, before skill-library editing. "
    "This is training-only reflection, not inference, a new judge, or a generated corrected answer. "
    "Every current source is complete; original labels/member sets and matched empty/current-memory "
    "answers are supplied. The original task contract and actual source-reading inputs are retained. "
    "For EACH source, preserve what demonstrably worked and identify consequential label mistakes, "
    "missing members, extra citations, and concrete guidance misapplications. Report concise, "
    "public evidence findings and actionable source-reading changes, not hidden chain of thought. "
    "Resolve every cited index against that source. Never use a local excerpt to establish whole-source "
    "absence. Distinguish a complete original member set from a smallest sufficient proof. "
    "Inspect the REAL parent procedure AND historical examples: a correct-sounding instruction can "
    "still confuse this model. 'The rule already says this' is not an execution diagnosis. Where "
    "an instruction was ignored, specify a simpler observable action, an applicability distinction, "
    "a misleading comparison to remove, or explicitly say the cause remains unestablished. "
    "Related parent IDs are diagnostic associations, not experimentally isolated causal attribution. "
    "Do not infer that every memory/empty difference is a skill's causal effect or that every "
    "provided original label is universal legal doctrine. Preserve opposing examples and actual "
    "failures. No synthetic trajectories, future cases, proposed current answers, mandatory edits, "
    "case-specific rule tables, performance admission, best-bank rollback, or tools. The later "
    "curator, not this reflection, makes all library edits. A source with no supported improvement "
    "can have an empty findings list. Return the exact JSON schema."
)


def reflection_schema(rows, labels, bank):
    """Bind every supplied source and original coordinate, not teacher conclusions."""
    parent_ids = [s['id'] for s in bank]
    related = {'type': 'array', 'items': {'type': 'string'}}
    if parent_ids:
        related['items']['enum'] = parent_ids
    else:
        related['maxItems'] = 0
    cases = {}
    for row in rows:
        finding = {'type': 'object', 'additionalProperties': False,
            'required': ['hypothesis_id', 'observed_failure', 'source_original_indices',
                         'source_reading_action', 'related_parent_skill_ids'],
            'properties': {
                'hypothesis_id': {'type': 'string', 'enum': list(labels)},
                'observed_failure': {'type': 'string'},
                'source_original_indices': {'type': 'array', 'items': {
                    'type': 'integer', 'enum': list(range(len(row['spans'])))}},
                'source_reading_action': {'type': 'string'},
                'related_parent_skill_ids': copy.deepcopy(related)}}
        cases[str(row['id'])] = {'type': 'object', 'additionalProperties': False,
            'required': ['preserve_observed_successes', 'findings'], 'properties': {
                'preserve_observed_successes': {'type': 'string'},
                'findings': {'type': 'array', 'items': finding}}}
    return {'type': 'object', 'additionalProperties': False,
        'required': ['case_findings', 'cross_source_execution_lessons'], 'properties': {
            'case_findings': {'type': 'object', 'additionalProperties': False,
                'required': list(cases), 'properties': cases},
            'cross_source_execution_lessons': {'type': 'array', 'items': {'type': 'string'}}}}


class WitnessedExperience(RankedOnline):
    teaching_system = TEACHER_SYSTEM

    def new_fit_count(self):
        return len(self.fit_records)

    def observe(self, units, *, source_rows=None, artifact_root=None):
        values, contexts, contracts = [], {}, {}
        sources = {r['id']: r for r in (self.documents if source_rows is None else source_rows)}
        artifacts = self.out if artifact_root is None else Path(artifact_root)
        for u in units:
            row = sources[u['document_id']]
            actual = read(artifacts / f"inputs/{u['stage']}/{u['document_id']}/{u['condition']}.json")
            native_body = json.loads(actual['messages'][1]['content'])
            properties = actual['schema']['properties']
            common = next(iter(properties.values()))
            assert all(v == common for v in properties.values())
            assert set(properties) == set(actual['schema']['required'])
            contract = {
                'actual_system_messages': [m for m in actual['messages'] if m['role'] == 'system'],
                'actual_user_visible_output_contract': native_body['output_contract'],
                'actual_schema_root': {k:v for k,v in actual['schema'].items() if k != 'properties'},
                'actual_common_hypothesis_schema': common,
                'common_schema_applies_verbatim_to_every_required_hypothesis': True}
            contract_ref = csha(contract)
            contracts.setdefault(contract_ref, contract)
            delivery = read(artifacts / f"deliveries/{u['stage']}/{u['document_id']}/{u['condition']}.json")
            context = delivery.pop("actual_visible_candidates")
            ref = csha(context)
            contexts.setdefault(ref, context)
            feedback = {}
            for q in u['queries']:
                gold = set(q['gold']['spans'])
                cited = set(q['prediction']['spans']) if q['prediction'] is not None else set()
                def excerpts(indices):
                    return table([{'original_span_index':i,
                        'literal_original_text':row['text'][slice(*row['spans'][i])]}
                        for i in sorted(indices)])
                feedback[q['hypothesis_id']] = {**copy.deepcopy(q),
                    'retained_original_member_indices': sorted(gold & cited),
                    'missed_original_members': excerpts(gold - cited),
                    'extra_actual_citations': excerpts(cited - gold)}
            values.append({
                "document_id": u["document_id"], "stage": u["stage"], "bank_sha256": u["bank_sha256"],
                "actual_ordinary_tool_source_ids": u["ordinary_tool_source_ids"],
                "actual_native_answer": u["parsed"], "public_valid": u["public_valid"],
                "invalid_native_content": None if u["public_valid"] else u["response"]["content"],
                "actual_delivery": delivery, "actual_candidate_context_ref": ref,
                "actual_lawyer_task_contract_ref": contract_ref,
                "original_component_feedback": keyed(feedback)})
        return {"encoding": "lossless_source_candidates_and_actual_task_contracts_v2",
                "candidate_contexts": contexts, "lawyer_task_contracts": contracts,
                "observations": table(values), "all_actual_candidates_scores_and_text_retained": True,
                "original_member_credit_is_exact_set_difference_not_a_new_judge": True}

    def publish(self, body, name, *, teaching_system=None):
        parent = copy.deepcopy(self.bank)
        catalog = body["eligible_original_non_neutral_historical_witnesses"]
        nonmembers = body['eligible_actual_false_citation_contrasts']
        window = expand(body["complete_already_revealed_original_source_window_and_Gold"])
        allowed = sorted({r["id"] for r in window} | {
            x['source_case_id'] for x in [*catalog.values(), *nonmembers.values()]})
        guidance = witnessed_guidance_schema(catalog, nonmembers)
        schema = differential_schema(self.labels, parent, allowed, guidance_schema=guidance)
        body["current_parent_library"] = parent
        body["current_materialized_parent_including_all_past_evidence_texts"] = self.materialized
        body["library_budget"] = {"current_materialized_target8B_tokens": self.memory_tokens,
                                  "target_tokens": 2800, "hard_tokens": 4096}
        self.progress("memory_budget", current_arm=name,
                      exact_CPU_tokenizer_cost_requests=len(catalog)+len(nonmembers))
        assert not set(catalog) & set(nonmembers)
        body["exact_standalone_example_target8B_token_costs"] = {
            ref: self.meter.token_count(text=json.dumps(witness_membership_example(w),
                ensure_ascii=False, separators=(",", ":")))
            for ref, w in {**catalog, **nonmembers}.items()}
        body["token_costs_are_existing_CPU_tokenizer_requests_not_native_generations"] = len(catalog)+len(nonmembers)
        self.record(f"learning_inputs/{name}.json", body)
        teacher_body = encode_teacher_body(body)
        system = self.teaching_system if teaching_system is None else teaching_system
        reference = self.cfg.get('completed_record_intervention_reference_run')
        if reference and name == 'credit_b4':
            old_wire = ROOT/'runs'/reference/'teacher/credit_b4/wire_request.json'
            actual = read(old_wire)
            assert actual['system_prompt'] == system and actual['output_schema'] == schema
            assert actual['user_prompt'] == json.dumps(teacher_body, ensure_ascii=False, separators=(',', ':'))
            self.record('exact_unfinished_teacher_request_resume.json', {
                'at':now(), 'source_wire':str(old_wire), 'source_wire_sha256':sha(old_wire),
                'same_system_user_schema_model_and_effort':True,
                'new_run_purpose_only_no_answer_or_library_selection':True})
        delta = self.teacher_call(name, system, teacher_body, schema)
        bank = apply_differential_publication(parent, delta, self.labels, allowed, guidance_schema=guidance)
        materialized = materialize_witness_skills(bank, self.labels, catalog, nonmembers)
        tokens = self.meter.token_count(text=json.dumps(witness_knowledge_view(materialized),
            ensure_ascii=False, separators=(",", ":")))
        audit_storage_tokens = self.meter.token_count(text=json.dumps(materialized,
            ensure_ascii=False, separators=(",", ":")))
        assert tokens <= 4096, "Complete materialized knowledge exceeds capacity; no clipping, gate or old-bank substitute"
        stats = publication_statistics(parent, delta, bank, tokens)
        self.record(f"publications/{name}.json", {
            "at": now(), "parent": parent, "delta": delta, "publication": bank,
            "materialized_runtime_memory": materialized, "statistics": stats,
            "source_ids_actually_available_to_teacher": allowed,
            "all_valid_edits_used_without_utility_gate": True,
            "complete_model_delivered_knowledge_target8B_tokens": tokens,
            "internal_audit_storage_target8B_tokens_reported_separately": audit_storage_tokens,
            "exact_tokenizer_budget_requests_not_native_generations": len(catalog)+len(nonmembers)+2})
        self.bank, self.materialized, self.catalog, self.memory_tokens = bank, materialized, catalog, tokens
        self.nonmember_catalog = nonmembers
        self.publication_history.append(stats)

    def answer_mode(self, row, mode, proposals):
        role = "joint_empty" if mode == "empty" else "skills"
        messages, schema, delivery = witnessed_skill_payload(
            row, self.labels, proposals, self.cfg["bundled_solver_system"], self.materialized, mode=mode)
        native = self.generate(row, role, messages, schema)
        body = json.loads(messages[1]["content"])
        self.record(f"deliveries/{self.phase}/{row['id']}/{role}.json", {
            **delivery, "actual_native_raw_id": native["raw_id"], "materialized_bank_sha256": csha(self.materialized),
            "actual_source_read_selection": proposals["selection"],
            "actual_visible_candidates": {"hypotheses": body["hypotheses"],
                                          "candidate_original_text": body["candidate_original_text"]}})
        return self.logical(row, role, native)



class WitnessedOnline(WitnessedExperience):
    """Full chronological skill learning; shared trained read access is not skill gain."""

    teaching_system = TEACHER_SYSTEM + (
        " This is the MAIN chronological online run, not a four-arm pilot. Only actual same-case "
        "empty-versus-current-memory pairs and the previous actual before/after publication are supplied. "
        "The library starts EMPTY; the ordinary prior202 is shared tool supervision, not your skill "
        "experience. Every batch is taught exactly once and every valid edit executes on ALL current8. "
        "Cold identical-policy aliases are one physical answer, never independent exploration. "
        "The complete-source window is current8 plus previous8; older retained witnesses are exact "
        "past evidence, not fabricated fresh answers or full old documents. Publication feedback is "
        "actual same-tool before/after, including all harms; never treat it as guaranteed success. "
        "Reading access is deliberately recall-favouring and calibrated ONLY on prior TRAIN. These "
        "broader candidates are optional source leads, not evidence answers or legal confidence. "
        "Diagnose original NN members missed inside and outside the leads. Correct NM gains alone "
        "are NOT improved evidence acquisition. For correct relations with incomplete evidence, repair "
        "source inspection rather than simply demanding more explicit wording or switching to NM. "
        "Contrast your OWN selected witnesses with your procedure; do not synthesize a universal "
        "permission or exclusion inconsistent with the supplied counterexamples. If original labels "
        "have an ambiguous boundary, preserve the observed distinction without inventing universal law "
        "or deleting inconvenient source data. A separate training reflector has inspected every "
        "current source and actual matched answers before this edit. Its findings are evidence-based "
        "learning proposals, not verified causal claims or mandatory edits. Reconcile them with the "
        "full original feedback and actual previous publication effects. Repair operational delivery, "
        "not just legal-rule wording: deleting an overgeneralized example, splitting a confusing "
        "procedure or replacing an unexecutable instruction can be justified even when no new legal "
        "boundary was discovered. Do not equate 'already mentioned' with 'successfully executed'. "
        "Keep useful content; NOOP remains valid when no supported change is available. "
        "No manual case exceptions, fixed library size, efficacy "
        "admission, best-bank rollback or future-case knowledge."
    )

    def generate(self, row, role, messages, schema):
        reference = self.cfg.get('completed_record_intervention_reference_run')
        if reference and self.current_batch == 4 and self.phase.startswith('b4_remove_record_'):
            old = ROOT/'runs'/reference
            ip, np, lp = [old/f'{kind}/{self.phase}/{row["id"]}/{role}.json'
                          for kind in ('inputs','native','logical_answers')]
            assert role == 'skills' and read(ip) == {'messages':messages, 'schema':schema}
            response, logical = read(np)['response'], read(lp)
            assert response == logical['response'] and response['finish_reason'] == 'stop'
            assert logical['bank_sha256'] == csha(self.bank)
            assert logical['ordinary_tool_source_ids'] == self.prefix_ids
            self.record(f'inputs/{self.phase}/{row["id"]}/{role}.json', read(ip))
            self.record(f'inherited_completed_interventions/{self.phase}/{row["id"]}.json', {
                'source_input':str(ip), 'source_input_sha256':sha(ip),
                'source_native':str(np), 'source_native_sha256':sha(np),
                'source_logical':str(lp), 'source_logical_sha256':sha(lp),
                'actual_original_response':response, 'new_native_calls':0,
                'already_costed_completed_generation_not_retry_or_independent_sample':True})
            self.inherited_intervention_count += 1
            return response
        return super().generate(row, role, messages, schema)

    def reflect_current_batch(self, body, rows):
        """ACE-inspired reflection before curation; no new lawyer call or inference layer."""
        current = {r['id'] for r in rows}
        window = expand(body['complete_already_revealed_original_source_window_and_Gold'])
        selected = [r for r in window if r['id'] in current]
        assert [r['id'] for r in selected] == [r['id'] for r in rows]
        packet = {
            'public_hypotheses': self.labels,
            'complete_current_original_sources_and_Gold': table(selected),
            'all_actual_current8_matched_empty_and_memory_observations':
                body['all_actual_current8_matched_empty_and_memory_observations'],
            'actual_current_batch_metrics': body['actual_current_batch_metrics'],
            'current_parent_library': copy.deepcopy(self.bank),
            'actual_materialized_parent': copy.deepcopy(self.materialized),
            'same_ordinary_tool_and_original_metrics': True,
            'all_current_sources_reflected_not_selected_by_success': True,
            'no_future_source_or_Gold_and_not_runtime_answer_correction': True}
        name = f'reflect_b{self.current_batch}'
        self.record(f'learning_inputs/{name}.json', packet)
        result = self.teacher_call(name, REFLECTION_SYSTEM, encode_teacher_body(packet),
                                   reflection_schema(rows, self.labels, self.bank))
        self.record(f'reflections/b{self.current_batch}.json', {
            'at': now(), 'actual_teacher_name': name,
            'source_ids': [r['id'] for r in rows], 'value': result,
            'diagnostic_associations_not_isolated_causal_proof': True,
            'not_served_to_lawyer_or_used_as_current_case_answer': True})
        return result

    def cold_alias(self, row, proposals, empty):
        assert not self.bank and not self.materialized and self.current_batch == 1
        messages, schema, delivery = witnessed_skill_payload(row, self.labels, proposals,
            self.cfg["bundled_solver_system"], [], mode="combined")
        original_input = self.out / f"inputs/b1_prequential_empty/{row['id']}/joint_empty.json"
        actual = read(original_input)
        assert actual == {"messages": messages, "schema": schema}
        native_path = self.out / f"native/b1_prequential_empty/{row['id']}/joint_empty.json"
        assert read(native_path)["response"] == empty["response"]
        self.record(f"inputs/{self.phase}/{row['id']}/skills.json", actual)
        body = json.loads(messages[1]["content"])
        self.record(f"deliveries/{self.phase}/{row['id']}/skills.json", {
            **delivery, "actual_native_raw_id": empty["response"]["raw_id"],
            "materialized_bank_sha256": csha([]), "actual_source_read_selection": proposals["selection"],
            "explicit_identical_policy_physical_alias_not_an_independent_rollout": True,
            "actual_visible_candidates": {"hypotheses": body["hypotheses"],
                                          "candidate_original_text": body["candidate_original_text"]}})
        self.record(f"aliases/cold_{row['id']}.json", {
            "at": now(), "source_native_path": str(native_path), "source_input_path": str(original_input),
            "input_and_schema_exactly_equal": True, "new_native_calls": 0,
            "original_raw_id_and_content_preserved": True})
        return self.logical(row, "skills", empty["response"])

    def leads(self, row):
        return evidence_proposals(self.prefix_model, row, self.labels,
                                  reading_threshold=self.reading_policy["threshold"])

    def learning_body(self, window, fresh, metrics):
        """One complete chronological teacher packet, also used for causal readouts."""
        gold = read(ROOT / self.cfg['grading_only'])['original_TRAIN_annotations']
        catalog = training_witness_catalog(window, self.labels, gold)
        nonmembers = training_nonmember_catalog(window, self.labels, self.units)
        for skill in self.bank:
            for ref in skill['guidance']['witness_refs']:
                catalog.setdefault(ref, self.catalog[ref])
            for ref in skill['guidance']['nonmember_refs']:
                nonmembers.setdefault(ref, self.nonmember_catalog[ref])
        return {'public_hypotheses': self.labels,
            'complete_already_revealed_original_source_window_and_Gold': annotated_sources(window, self.labels, gold),
            'eligible_original_non_neutral_historical_witnesses': catalog,
            'eligible_actual_false_citation_contrasts': nonmembers,
            'all_actual_current8_matched_empty_and_memory_observations': self.observe(fresh),
            'actual_current_batch_metrics': metrics,
            'current_shared_ordinary_tool_source_ids': self.prefix_ids,
            'shared_training_only_reading_policy_not_skill_gain': self.reading_policy,
            'cold_policy_aliases_are_one_physical_answer_not_independent_sampling': self.current_batch == 1,
            'previous_actual_complete8_publication_experience': self.last_update,
            'no_future_source_text_answers_annotations_or_official_DEV_TEST': True,
            'outside_window_old_sources_not_reanswered_no_all_seen_retention_claim': True}

    def learn_with_record_removal_feedback(self, rows, empty_units, full_units, window, name):
        """Measure actual record-level interventions before ONE unconditional edit.

        A record includes its procedure and all selected examples. This measures
        its conditional marginal effect, not independent text components, a
        universal causal effect, or the model's unobserved internal skill use.
        No arm is admitted, chosen as a bank, or deployed because of its score.
        """
        parent, materialized = copy.deepcopy(self.bank), copy.deepcopy(self.materialized)
        prior_own, prior_phase, prior_tokens = dict(self.own_current), self.phase, self.memory_tokens
        assert len(rows) == len(empty_units) == len(full_units) == 8
        assert {r['id'] for r in rows} == {u['document_id'] for u in full_units}
        assert all(u['bank_sha256'] == csha(parent) for u in full_units)
        start = len(self.answers)
        try:
            for index, removed in enumerate(parent):
                self.bank = [s for s in parent if s['id'] != removed['id']]
                self.materialized = [s for s in materialized if s['id'] != removed['id']]
                assert {s['id'] for s in self.bank} == {s['id'] for s in self.materialized}
                self.memory_tokens = self.meter.token_count(text=json.dumps(
                    witness_knowledge_view(self.materialized), ensure_ascii=False, separators=(',', ':')))
                self.phase = f'b{self.current_batch}_remove_record_{index}'
                self.record(f'skill_removal_interventions/b{self.current_batch}/record_{index}.json', {
                    'removed_parent_id': removed['id'], 'removed_complete_record': removed,
                    'retained_library': self.bank, 'retained_materialized_memory': self.materialized,
                    'structural_training_intervention_not_a_library_publication': True})
                for row in rows:
                    self.answer_mode(row, 'combined', self.leads(row))
        finally:
            self.bank, self.materialized, self.memory_tokens = parent, materialized, prior_tokens
            self.own_current, self.phase = prior_own, prior_phase
        # No intervention outcome can alter the remaining generation schedule.
        actual = self.score(self.answers[start:])
        assert len(actual) == len(parent)*8
        self.units.extend(actual)
        effects = []
        for index, removed in enumerate(parent):
            units = [u for u in actual if u['stage'] == f'b{self.current_batch}_remove_record_{index}']
            assert len(units) == 8
            effects.append({'removed_parent_id': removed['id'],
                'retained_parent_ids': [s['id'] for s in parent if s['id'] != removed['id']],
                'effect_full_to_removed': paired_effect(full_units, units,
                    seed=2026101930+index, replicates=5000),
                'all_actual_removed_condition_observations': self.observe(units)})
        body = self.learning_body(window, empty_units+full_units,
            {'empty': points(empty_units), 'combined': points(full_units)})
        body['actual_record_removal_feedback'] = {
            # The same complete parent observations already occur in the matched
            # current packet. Refer to those exact raw IDs rather than duplicating
            # their contracts/candidates/feedback and exceeding the CLI char cap.
            'full_parent_library_reference': {
                'field': 'all_actual_current8_matched_empty_and_memory_observations.observations',
                'bank_sha256': csha(parent),
                'ordered_document_id_native_raw_id_pairs': [
                    [u['document_id'], u['response']['raw_id']] for u in full_units],
                'exact_full_observations_already_supplied_not_summarized': True},
            'record_removals': effects,
            'same_current_source_tool_schema_generation_and_scoring': True,
            'single_sample_per_source_not_population_or_token_matched_effect': True,
            'removal_does_not_identify_rule_vs_example_or_other_interactions': True,
            'all_removed_arms_are_diagnostics_not_admission_candidates': True}
        self.record(f'skill_removal_interventions/{name}_all_effects.json', body['actual_record_removal_feedback'])
        notice = (
            ' This is ONE actual chronological correction with measured record-removal feedback. '
            'No separate reflector call was made for this update. Every parent record was removed '
            'in turn on ALL current8 sources, retaining every other record and the exact same '
            'ordinary model, native output contract and generation settings. The actual original '
            'component scores and exact public answers for every arm are supplied. A positive '
            'full_to_removed change suggests this COMPLETE record interfered conditional on this '
            'bank and these samples; a negative change suggests it helped. These are NOT universal '
            'causal effects, token-matched controls, proof of internal use, or a separation of the '
            'procedure from its examples. Do not fabricate missing pairwise interactions or '
            'finer attribution. Diagnose cross-hypothesis harms as well as in-scope effects. '
            'Use the actual interventions to simplify, rewrite, split, merge, delete or retain '
            'content; do not merely restate correct-sounding legal advice. Preserve complete '
            'original member boundaries rather than substituting a smallest proof. All measured '
            'arms, successes and harms are retained. The host does NOT pick the best ablation or '
            'require your update to pass a score. You alone choose valid ordinary CRUD/NOOP; '
            'every structurally valid edit is published and the actual result, including failure '
            'or an empty bank, will be measured. No case-specific rule table, runtime answer '
            'correction, future source/Gold or invented label. Keep knowledge within the same4096 '
            'target8B tokens, without forced size or growth.')
        self.publish(body, name, teaching_system=TEACHER_SYSTEM+notice)
        return effects

    def inherit_prequential(self, row, mode):
        """Exact completed next-batch observations, not new independent calls."""
        role = 'joint_empty' if mode == 'empty' else 'skills'
        old = ROOT/'runs'/self.cfg['initial_completed_run']
        stage = 'forward_b4_empty' if mode == 'empty' else 'forward_b4_learned'
        paths = {kind: old/f'{kind}/{stage}/{row["id"]}/{role}.json'
                 for kind in ('inputs', 'native', 'logical_answers', 'deliveries')}
        messages, schema, _ = witnessed_skill_payload(row, self.labels, self.leads(row),
            self.cfg['bundled_solver_system'], self.materialized, mode=mode)
        actual, logical = read(paths['inputs']), read(paths['logical_answers'])
        native = read(paths['native'])['response']
        assert actual == {'messages': messages, 'schema': schema}
        assert logical['response'] == native and native['finish_reason'] == 'stop'
        assert logical['ordinary_tool_source_ids'] == self.prefix_ids
        assert logical['bank_sha256'] == csha(self.bank if mode != 'empty' else [])
        self.record(f'inputs/{self.phase}/{row["id"]}/{role}.json', actual)
        self.record(f'deliveries/{self.phase}/{row["id"]}/{role}.json', read(paths['deliveries']))
        self.record(f'inherited_completed_prequential/{row["id"]}/{role}.json', {
            'at': now(), 'actual_original_response': native,
            'source_artifacts': {k: {'path': str(p), 'sha256': sha(p)} for k,p in paths.items()},
            'exact_input_schema_generation_bank_and_shared_tool_verified': True,
            'new_native_calls': 0, 'not_an_independent_sample_or_favourable_case_selection': True})
        self.inherited_prequential_count += 1
        return self.logical(row, role, native)

    def execute_record_credit_continuation(self):
        """Continue the actual published bank through every remaining TRAIN batch.

        This is an explicitly adaptive development lineage, not a uniform
        independent128 run. No old bank is selected by its measured score.
        """
        offset = self.cfg['global_batch_offset']
        assert offset == 3 and len(self.documents) == (16-offset)*8
        assert [r['id'] for r in self.documents] == self.cfg['episode_ids']
        assert len(self.past) == len(self.prefix_ids) == 202+offset*8
        old = ROOT/'runs'/self.cfg['initial_completed_run']
        completion = read(old/'completion.json')
        publication = read(ROOT/self.cfg['initial_actual_publication'])
        assert read(ROOT/self.cfg['initial_terminal_receipt'])['state'] == 'terminal_results_preserved'
        assert self.cfg['generation'] == read(ROOT/self.cfg['initial_completed_config'])['generation']
        assert self.bank == publication['publication'] == completion['actual_terminal_library']
        assert self.prefix_ids == completion['ordinary_source_ids']
        self.materialized = copy.deepcopy(publication['materialized_runtime_memory'])
        assert self.materialized == completion['actual_terminal_materialized_memory']
        self.catalog = {w['witness_ref']: {k:v for k,v in w.items() if k != 'witness_ref'}
                        for s in self.materialized for w in s['witnesses']}
        self.nonmember_catalog = {w['nonmember_ref']: {k:v for k,v in w.items() if k != 'nonmember_ref'}
                                  for s in self.materialized for w in s['nonmembers']}
        self.memory_tokens = self.meter.token_count(text=json.dumps(witness_knowledge_view(self.materialized),
            ensure_ascii=False, separators=(',', ':')))
        assert self.memory_tokens == completion['actual_terminal_knowledge_tokens'] <= 4096
        self.reading_policy = read(ROOT/self.cfg['reading_calibration_completion'])['reading_policy']
        previous = [u for u in completion['all_actual_units_and_adverse_results']
                    if u['stage'] in ('inherited_b3_combined', 'credit_b3_actual_after')]
        assert len(previous) == 16 and {u['document_id'] for u in previous} == {r['id'] for r in self.past[-8:]}
        self.last_update = {'parent_library': publication['parent'], 'delta': publication['delta'],
            'published_library': self.bank,
            'all8_actual_before_and_after': self.observe(previous,
                source_rows=self.past[-8:], artifact_root=old),
            'original_training_effect': completion['actual_same_tool_training_publication_effect'],
            'same_ordinary_source_ids': previous[0]['ordinary_tool_source_ids'],
            'reading_policy': self.reading_policy, 'not_a_selected_successful_update': True}
        self.units.extend(previous)  # Real past false citations remain eligible learning examples.
        self.publication_history, self.inherited_prequential_count = [], 0
        self.inherited_intervention_count = 0
        reference = self.cfg.get('completed_record_intervention_reference_run')
        if reference:
            failed = read(ROOT/'runs'/reference/'failure.json')
            assert failed['actual_native_teacher_CPUfits'] == [32,0,0]
            assert failed['actual_teacher_attempts'] == 1
            assert not (ROOT/'runs'/reference/'publications').exists()
            assert self.cfg['generation'] == read(ROOT/self.cfg['completed_record_intervention_reference_config'])['generation']
        remaining = len(self.documents)//8
        self.record('declaration.json', {'at': now(), 'config': self.cfg,
            'frozen_bindings': self.bindings.copy(), 'actual_initial_terminal_library': self.bank,
            'actual_initial_materialized_memory': self.materialized,
            'initial_shared_ordinary_source_ids': self.prefix_ids,
            'chronological_batches': list(range(offset+1,17)), 'complete_remaining_source_count': len(self.documents),
            'planned_new_teacher_calls_and_CPUfits': [remaining, remaining],
            'planned_new_native_calls_formula': '24*remaining_batches-16-inherited_interventions + 8*sum(actual_parent_record_counts)',
            'native_call_estimate_only_if_initial_record_count_stays_fixed':
                24*remaining-16-(32 if reference else 0)+8*remaining*len(self.bank),
            'explicit_inherited_first8_empty_and_actual_terminal_memory_physical_calls': 16,
            'explicit_inherited_completed_record_intervention_physical_calls':32 if reference else 0,
            'no_forced_record_count_growth_efficacy_admission_or_best_bank_rollback': True,
            'one_actual_record_credit_curator_per_batch_no_separate_reflector': True,
            'same_source_witnesses_excluded_even_for_training_reanswers': True,
            'adaptive_mixed_history_not_independent_uniform128_or_official_TEST': True,
            'official_DEV_TEST_not_used_for_tuning': True})
        summaries = []
        for local in range(remaining):
            batch = self.current_batch = offset+local+1
            rows, start = self.documents[local*8:(local+1)*8], len(self.answers)
            assert len(self.prefix_ids) == 202+(batch-1)*8
            for index,row in enumerate(rows):
                for mode in (('empty','combined') if index%2 == 0 else ('combined','empty')):
                    self.phase = f'b{batch}_prequential_'+mode
                    if local == 0:
                        self.inherit_prequential(row, mode)
                    else:
                        self.answer_mode(row, mode, self.leads(row))
            fresh = self.score(self.answers[start:])
            self.units.extend(fresh)
            groups = {m:[u for u in fresh if u['stage'].endswith('_'+m)] for m in ('empty','combined')}
            assert all(len(v) == 8 for v in groups.values())
            metrics = {m:points(v) for m,v in groups.items()}
            summary = {'at': now(), 'batch': batch, 'new_source_ids': [r['id'] for r in rows],
                'metrics': metrics, 'same_case_skill_effect': paired_effect(groups['empty'], groups['combined'],
                    seed=2026102100+batch, replicates=5000),
                'current_bank_sha256': csha(self.bank), 'current_skill_count': len(self.bank),
                'knowledge_tokens': self.memory_tokens, 'shared_ordinary_source_ids': self.prefix_ids,
                'shared_reading_policy': self.reading_policy,
                'first_batch_observations_are_explicit_already_completed_actual_calls': local == 0,
                'later_batches_all16_generated_before_current_annotations_scored': local != 0}
            self.record(f'batch_summaries/b{batch}_before.json', summary)
            summaries.append(summary)
            print(json.dumps({'batch':batch, 'prequential_metrics':metrics}), flush=True)
            seen = self.documents[:(local+1)*8]
            parent, prior_materialized = copy.deepcopy(self.bank), copy.deepcopy(self.materialized)
            name = f'credit_b{batch}'
            self.learn_with_record_removal_feedback(rows, groups['empty'], groups['combined'],
                (self.past+seen)[-16:], name)
            start_after, self.phase = len(self.answers), f'b{batch}_after_seen_combined'
            for row in rows:
                self.answer_mode(row, 'combined', self.leads(row))
            after = self.score(self.answers[start_after:])
            self.units.extend(after)
            update = paired_effect(groups['combined'], after, seed=2026102200+batch, replicates=5000)
            self.record(f'update_effects/b{batch}.json', {'at':now(), 'effect':update,
                'same_actual_ordinary_model_and_reading_policy': True,
                'training_effect_not_new_source_transfer_or_skill_admission': True})
            published = read(self.out/f'publications/{name}.json')
            self.last_update = {'parent_library':parent, 'delta':published['delta'],
                'published_library':self.bank, 'parent_materialized_memory':prior_materialized,
                'all8_actual_before_and_after':self.observe(groups['combined']+after),
                'same_ordinary_source_ids':self.prefix_ids, 'reading_policy':self.reading_policy,
                'original_training_effect':update, 'not_a_selected_successful_update':True}
            self.fit_prefix(seen)
            completed = {**summary, 'at_complete':now(),
                'publication_statistics':self.publication_history[-1], 'actual_training_update_effect':update,
                'actual_after_seen_metrics':points(after), 'actual_published_skill_count':len(self.bank),
                'actual_published_knowledge_tokens':self.memory_tokens,
                'actual_new_native_teacher_CPUfits_so_far':[len(self.native),len(self.teachers),len(self.fit_records)]}
            self.record(f'batch_summaries/b{batch}_complete.json', completed)
            print(json.dumps({'batch_complete':batch, 'actual_training_update_effect':update['difference_after_minus_before'],
                'published_record_count':len(self.bank), 'knowledge_tokens':self.memory_tokens}), flush=True)
        assert self.inherited_prequential_count == 16
        assert len(self.teachers) == len(self.fit_records) == remaining and self.teacher_attempts >= remaining
        assert self.inherited_intervention_count == (32 if reference else 0)
        assert len(self.prefix_ids) == 330
        groups = {m:[u for u in self.units if '_prequential_' in u['stage'] and u['stage'].endswith('_'+m)]
                  for m in ('empty','combined')}
        assert all(len(v) == len(self.documents) for v in groups.values())
        result = {'at':now(), 'run_id':self.run_id,
            'all_remaining104_prequential_metrics':{m:points(v) for m,v in groups.items()},
            'all_remaining_source_paired_effect':paired_effect(groups['empty'], groups['combined'],
                seed=2026102300, replicates=5000),
            'actual_new_native_teacher_CPUfits':[len(self.native),len(self.teachers),len(self.fit_records)],
            'actual_teacher_attempts':self.teacher_attempts, 'inherited_prequential_physical_calls':16,
            'inherited_completed_intervention_physical_calls':self.inherited_intervention_count,
            'final_bank':self.bank, 'final_materialized_memory':self.materialized,
            'final_common_ordinary_source_ids':self.prefix_ids, 'actual_ordinary_fits':self.fit_records,
            'publication_statistics':self.publication_history, 'batch_summaries':summaries, 'units':self.units,
            'adaptive_continuation_not_independent_uniform128_baseline_superiority_or_official_TEST':True}
        self.record('completion.json', result)
        RunStore.atomic_json(self.out/'progress.json', {'at':now(), 'state':'completed', 'run_id':self.run_id,
            'completed_native_calls':len(self.native), 'completed_teacher_calls':len(self.teachers),
            'actual_new_CPUfits':len(self.fit_records),
            'all_remaining104_prequential_metrics':result['all_remaining104_prequential_metrics']})

    def execute(self):
        if self.cfg['study_kind'] == 'record_credit_remaining104_online':
            return self.execute_record_credit_continuation()
        assert self.cfg["method"] == EDIT_FEEDBACK_METHOD and len(self.documents) == 128
        assert self.cfg['teacher_task_contract_version'] == 'reflection_before_signed_publication_v3'
        assert len(self.past) == len(self.prefix_ids) == 202 and not self.bank
        assert [r["id"] for r in self.documents] == self.cfg["episode_ids"]
        calibration = read(ROOT / self.cfg["reading_calibration_completion"])
        assert calibration["actual_completed_CPUfits"] == 5
        assert set(calibration["source_fold_assignment"]) == {str(i) for i in self.prefix_ids}
        assert calibration["reading_policy"]["beta"] == 2
        self.reading_policy = calibration["reading_policy"]
        self.materialized, self.catalog, self.memory_tokens, self.publication_history = [], {}, 0, []
        self.nonmember_catalog = {}
        self.fit_records, self.last_update = [], None
        self.record("declaration.json", {
            "at": now(), "config": self.cfg, "frozen_bindings": self.bindings.copy(),
            "planned_new_native_teacher_CPUfits": [376,32,16], "planned_logical_answers": 384,
            "teacher_roles": {"training_batch_reflections": 16, "library_curations": 16},
            "reflection_not_an_inference_layer_or_skill_efficacy_gate": True,
            "only8_exact_cold_aliases_not_independent_exploration": True,
            "shared_prior202_calibration_and_growing_tool_not_skill_gain": True,
            "reading_policy": self.reading_policy, "independent_empty_memory_start": True,
            "prior_training_development_exposures_not_an_independent_algorithmic_repeat": True,
            "same_source_witnesses_excluded_even_for_training_reanswers": True,
            "official_DEV_TEST_not_used_for_tuning": True})
        summaries = []
        for batch in range(1,17):
            self.current_batch = batch
            rows, start = self.documents[(batch-1)*8:batch*8], len(self.answers)
            assert len(self.prefix_ids) == 202+(batch-1)*8
            for index, row in enumerate(rows):
                proposals = self.leads(row)
                if batch == 1:
                    self.phase = "b1_prequential_empty"
                    empty = self.answer_mode(row, "empty", proposals)
                    self.phase = "b1_prequential_combined"
                    self.cold_alias(row, proposals, empty)
                else:
                    for mode in (("empty","combined") if index%2 == 0 else ("combined","empty")):
                        self.phase = f"b{batch}_prequential_" + mode
                        self.answer_mode(row, mode, proposals)
            fresh = self.score(self.answers[start:])
            self.units.extend(fresh)
            groups = {m: [u for u in fresh if u["stage"].endswith("_"+m)] for m in ("empty","combined")}
            assert all(len(v) == 8 for v in groups.values())
            metrics = {m: points(v) for m,v in groups.items()}
            effect = paired_effect(groups["empty"],groups["combined"],seed=2026101980+batch,replicates=5000)
            summary = {"at": now(), "batch": batch, "new_source_ids": [r["id"] for r in rows],
                "metrics": metrics, "same_case_skill_effect": effect,
                "current_bank_sha256": csha(self.bank), "current_skill_count": len(self.bank),
                "knowledge_tokens": self.memory_tokens, "shared_ordinary_source_ids": self.prefix_ids,
                "shared_reading_policy": self.reading_policy,
                "all_current8_both_views_generated_before_current_Gold": True}
            self.record(f"batch_summaries/b{batch}_before.json", summary)
            summaries.append(summary)
            print(json.dumps({"batch": batch, "metrics": metrics}), flush=True)
            seen = self.documents[:batch*8]
            window = seen[-16:]
            body = self.learning_body(window, fresh, metrics)
            parent, before_materialized = copy.deepcopy(self.bank), copy.deepcopy(self.materialized)
            name = f"online_b{batch}"
            body['actual_training_reflection_before_curation'] = self.reflect_current_batch(body, rows)
            self.publish(body, name)
            start_after, self.phase = len(self.answers), f"b{batch}_after_seen_combined"
            for row in rows:
                self.answer_mode(row, "combined", self.leads(row))
            after = self.score(self.answers[start_after:])
            self.units.extend(after)
            update = paired_effect(groups["combined"],after,seed=2026102000+batch,replicates=5000)
            self.record(f"update_effects/b{batch}.json", {
                "at": now(), "effect": update, "same_current_ordinary_tool_and_reading_policy": True,
                "same_source_witness_exclusion_on_all8_training_reanswers": True,
                "training_effect_not_new_source_transfer_or_skill_admission": True})
            publication = read(self.out/f"publications/{name}.json")
            self.last_update = {"parent_library": parent, "delta": publication["delta"],
                "published_library": self.bank, "parent_materialized_memory": before_materialized,
                "all8_actual_before_and_after": self.observe(groups["combined"]+after),
                "same_ordinary_source_ids": self.prefix_ids, "reading_policy": self.reading_policy,
                "original_training_effect": update, "not_a_selected_successful_update": True}
            self.record(f"batch_summaries/b{batch}_complete.json", {**summary,
                "publication_statistics": self.publication_history[-1], "actual_training_update_effect": update})
            self.fit_prefix(seen)
        assert len(self.native) == 376 and len(self.answers) == 384
        assert len(self.teachers) == 32 and len(self.fit_records) == 16 and len(self.prefix_ids) == 330
        groups = {m: [u for u in self.units if "_prequential_" in u["stage"] and u["stage"].endswith("_"+m)]
                  for m in ("empty","combined")}
        assert all(len(v) == 128 for v in groups.values())
        result = {"at": now(), "run_id": self.run_id, "all128_prequential_metrics": {m:points(v) for m,v in groups.items()},
            "all128_source_paired_effect": paired_effect(groups["empty"],groups["combined"],seed=2026102020,replicates=5000),
            "batch_summaries": summaries, "actual_new_native_teacher_CPUfits": [376,32,16],
            "actual_teacher_roles": {"training_batch_reflections": 16, "library_curations": 16},
            "inherited_shared_read_calibration_CPUfits": 5,
            "prior_development_family_native_teacher_CPUfits": self.cfg["prior_development_family_native_teacher_CPUfits"],
            "total_this_development_family_native_teacher_CPUfits": [a+b for a,b in zip(
                [376,32,16],self.cfg["prior_development_family_native_teacher_CPUfits"],strict=True)],
            "final_bank": self.bank, "final_materialized_memory": self.materialized,
            "final_common_ordinary_source_ids": self.prefix_ids, "actual_ordinary_fits": self.fit_records,
            "publication_statistics": self.publication_history, "units": self.units,
            "all_adverse_cases_invalids_and_original_denominators_preserved": True,
            "not_independent_algorithmic_repeat_mature_baseline_superiority_or_official_TEST": True}
        self.record("completion.json", result)
        RunStore.atomic_json(self.out/"progress.json", {
            "at": now(), "state": "completed", "run_id": self.run_id,
            "completed_native_calls": 376, "completed_teacher_calls": 32, "actual_new_CPUfits": 16,
            "all128_prequential_metrics": result["all128_prequential_metrics"]})
        print(json.dumps({"completed": self.run_id, "metrics": result["all128_prequential_metrics"]}),flush=True)


def main():
    with (ROOT / "artifacts/gpu_generation.lock").open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        config = Path(sys.argv[1])
        kind = read(config)["study_kind"]
        if kind not in ("full128_reflective_signed_member_skill_online", 'record_credit_remaining104_online'):
            raise ValueError("Only the full online protocol is active; finite historical studies remain in Git/archives")
        study = WitnessedOnline(config)
        try:
            study.execute()
        except BaseException as error:
            failure = {"at": now(), "state": "failed", "error": repr(error), "traceback": traceback.format_exc(),
                "actual_native_teacher_CPUfits": [len(study.native),len(study.teachers),study.new_fit_count()],
                "actual_teacher_attempts": study.teacher_attempts,
                "inherited_failed_native_teacher_CPUfits": study.cfg.get("inherited_failed_native_teacher_CPUfits", [0,0,0]),
                "no_retry_answer_repair_fallback_gate_or_selected_bank": True}
            study.record("failure.json", failure)
            RunStore.atomic_json(study.out / "progress.json", failure)
            raise


if __name__ == "__main__":
    main()
