"""One bounded TRAIN diagnosis: clause repair, then its execution representation.

Not a formal learning stream, validation split, frozen TEST, or new executor.
Uses Online's original HTTP, decoding, grading, dispatch and teacher transports.
Three immutable runs share one <=292-generation decision window. Proposals stop
for the main agent's semantic audit before any candidate outcome is generated.
"""

from __future__ import annotations

import argparse
import copy
import fcntl
import json
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path
from types import SimpleNamespace

from experiments.openexempt_online import (
    DIRECT_AUTHOR_SYSTEM, DIRECT_GUIDANCE, EXECUTION_AWARE_ADDITION,
    TASK_PROJECTION_TEACHING, FAMILIES, ROOT, Online, actor_payload,
    apply_differential_publication, csha, diagnosed_edit_schema,
    differential_schema, freeze, metrics, now, paired_effect, preserve, read, sha,
    task_view, validate_edit_diagnoses, validate_scoped_bank, validate_scopes,
    validate_task_projection_edit,
)
from legal_skill_guard.experiment.storage import RunStore

GROUP = "legal_openexempt_v6_EV_content_execution_TRAIN12_20261030_run01"
MAIN = "legal_openexempt_complete_output_utility_public_assets128_20261030_run01"
STRICT = "legal_openexempt_v6_strict_policy_control_public_assets128_20261030_run01"
MAIN_CONFIG = "configs/openexempt_complete_output_utility_public_assets128_20261030_run01.json"
MAIN_BANK = "48746352543b1a75627eb3cc9480a2257f42107fde544080aefbadc9cd2fca5d"
PLAN = ("artifacts/research/openexempt_legal_scope_20261020/"
        "Utility_v6_bounded_EV_TRAIN12_content_repair_then_same_rules_execution_representation_amended_before_calls_20261030.json")
PLAN_SHA = "a42e0d41304a75d328418e2fa64a82c1ec2e1787e5961cfa26768579098a91e5"
FIELDS = ("when", "procedure", "avoid_when")
LIMITS = {"propose": (12, 2), "screen": (24, 0), "confirm": (256, 0)}
QUEUE = ROOT / "artifacts/research/openexempt_legal_scope_20261020/Utility_v6_EV_TRAIN12_propose_after_strict_queue_20261030"


class StrictStillLive(RuntimeError):
    pass


def ref(path):
    return {"path": str(path.relative_to(ROOT)), "sha256": sha(path)}


def strict_finished():
    """A live PID or an unpreserved terminal must never release the GPU queue."""
    stat = Path("/proc/425484/stat")
    if stat.exists():
        fields = stat.read_text().rsplit(")", 1)[1].split()
        if fields[19] == "535803398" and fields[0] not in ("Z", "X"):
            raise StrictStillLive("The original strict control is still live; no diagnostic calls")
    source = ROOT / "runs" / STRICT
    if (source / "failure.json").exists():
        raise RuntimeError("Preserve and resolve the failed strict control before diagnosis")
    done = read(source / "completion.json")
    if done["status"] != "completed_bounded_mechanism_study":
        raise ValueError("This protocol requires the complete strict-control stream")
    receipt = read(source / "terminal_preservation.json")
    if len(receipt["paths"]) != 2:
        raise ValueError("The strict terminal has not been preserved on both disks")


def validate_config(path):
    cfg = read(path)
    stage = cfg["diagnostic_stage"]
    if stage not in LIMITS or cfg["run_id"] != GROUP + "_" + stage:
        raise ValueError("Only the declared three stages of this one window are allowed")
    parent = read(ROOT / MAIN_CONFIG)
    for key in ("generation", "teacher", "phase_dispatch", "inference_environment",
                "input_packet", "grading_directory", "execution_contract",
                "execution_contract_version", "actor_skill_order", "library_token_hard_cap"):
        if cfg[key] != parent[key]:
            raise ValueError("The diagnostic changed the original execution profile: " + key)
    if (cfg.get("diagnostic_not_formal_training") is not True
            or cfg["initial_library_publication"] != f"runs/{MAIN}/publications/b8.json"
            or cfg["planned_new_native_calls_max"] != LIMITS[stage][0]
            or cfg["planned_teacher_responses_max"] != LIMITS[stage][1]
            or cfg["protocol"] != read(ROOT / PLAN)["protocol"]["path"]):
        raise ValueError("Declare the actual diagnostic bank, budget and protocol")
    if sha(ROOT / PLAN) != PLAN_SHA:
        raise ValueError("The fixed TRAIN12 decision plan changed")
    plan = read(ROOT / PLAN)
    if sha(ROOT / cfg["protocol"]) != plan["protocol"]["sha256"]:
        raise ValueError("The decision protocol changed after fixing the cohort")
    if csha(read(ROOT / cfg["initial_library_publication"])["bank"]) != MAIN_BANK:
        raise ValueError("Use the completed actual main8 bank, not a chosen checkpoint")
    for name, digest in read((ROOT / MAIN_CONFIG).with_suffix(".frozen.json"))["files"].items():
        if sha(ROOT / name) != digest:
            raise ValueError("Original source/input profile changed: " + name)
    strict_finished()
    if stage != "propose":
        RepresentationDiagnosis.proposals()  # Bind real reviewed banks before freeze, not placeholders.
    if stage == "confirm":
        screen = ROOT / "runs" / (GROUP + "_screen")
        if ((screen / "failure.json").exists()
                or read(screen / "completion.json")["status"] != "completed_screen_qualified"
                or len(read(screen / "terminal_preservation.json")["paths"]) != 2):
            raise ValueError("Full128 requires the qualified, preserved real screen before freeze")
    return cfg, plan


def changed_block(bank, sid):
    records = [s for s in bank if s["id"] == sid]
    if len(records) != 1:
        raise ValueError("Clause repairs target one existing skill ID")
    blocks = [b for b in records[0]["guidance"]["by_task"] if b["tasks"] == ["EV"]]
    if len(blocks) != 1:
        raise ValueError("This diagnostic requires the existing separate EV projection")
    return blocks[0]


def verify_clause_repairs(parent, candidate, repairs, ids):
    """Audit exact author edits, never compute or correct an actor answer."""
    expected = copy.deepcopy(parent)
    for repair in repairs:
        field = repair["field"]
        if field not in FIELDS or not repair["source_case_ids"] or not set(repair["source_case_ids"]) <= ids:
            raise ValueError("Each literal clause repair needs its supplied TRAIN support")
        old, new = repair["old_text"], repair["replacement_text"]
        original = changed_block(parent, repair["skill_id"])
        block = changed_block(expected, repair["skill_id"])
        if not old or old == new or original[field].count(old) != 1 or block[field].count(old) != 1:
            raise ValueError("Repair exactly one unique original clause; no rewrite or silent deduplication")
        block[field] = block[field].replace(old, new, 1)
    if expected != candidate:
        raise ValueError("A changed text outside its declared literal content repairs")


def gains(before, after):
    a, b = metrics(before)["EV"], metrics(after)["EV"]
    return {key: 100 * (b[key] - a[key]) for key in ("f1", "full_output_f1")}


def subset(records, ids):
    return [r for r in records if r["case_id"] in ids]


class RepresentationDiagnosis(Online):
    def __init__(self, config_path):
        self.diagnostic, self.plan = validate_config(config_path)
        self.stage = self.diagnostic["diagnostic_stage"]
        self._reservations, self._reservation_lock = 0, threading.Lock()
        super().__init__(config_path)
        self.parent = copy.deepcopy(self.bank)
        self.ids = {v["source_case_id"] for v in self.plan["fixed_12_TRAIN_sources"]}
        self.controls = {v["source_case_id"] for v in self.plan["fixed_12_TRAIN_sources"]
                         if v["selection_role"] == "context_correct_control"}
        self.ev = [r for r in self.rows if r["family"] == "EV"]
        if (len(self.ev) != 128 or {r["case_id"] for r in self.ev} != set(range(181, 309))
                or len(self.ids) != 12 or len(self.controls) != 5):
            raise ValueError("Only the fixed original128 TRAIN and its fixed12 are permitted")

    def call(self, *args, **kwargs):
        with self._reservation_lock:
            if self._reservations >= LIMITS[self.stage][0]:
                raise RuntimeError("Physical native-call limit reached; no retry or extension")
            self._reservations += 1
        return Online.call(self, *args, **kwargs)

    def record(self, name, value):
        RunStore.immutable_json(self.out / name, value)

    def validate_bank(self, parent, candidate):
        validate_scoped_bank(candidate)
        validate_scopes(candidate, self.rows[0]["components"]["statutes"])
        validate_task_projection_edit(parent, candidate, "EV")
        count = self.meter.token_count(text=json.dumps(candidate, ensure_ascii=False, separators=(",", ":")))
        if count > 4096:
            raise ValueError("Complete bank over4096 tokens; retain failure without teacher reroll")
        for row in self.rows:
            if row["family"] == "EC":
                args = dict(grounded=True, direct_numeric=True, asset_references=True)
                if actor_payload(row, self.parent, **args)[:2] != actor_payload(row, candidate, **args)[:2]:
                    raise ValueError("The diagnostic changed an EC production message or schema")
        return count

    def teacher_packet(self, bank, observations, *, variant):
        focus = [r for r in self.ev if r["case_id"] in self.ids]
        # Only real historical empty records satisfy the original serializer's
        # bookkeeping. They are removed before the diagnostic wire is written.
        empty = []
        for n in range(1, 9):
            data = read(ROOT / "runs" / MAIN / f"batches/b{n}_prequential_records.json")
            empty.extend(r for r in data["empty"] if r["family"] == "EV" and r["case_id"] in self.ids)
        self.bank = copy.deepcopy(bank)
        self.prequential_empty = empty
        self.prequential_frozen = empty
        body = self.teacher_body(focus, focus, observations, [], teaching_task="EV")
        for case in body["already_seen_training"]:
            for key in list(case):
                if key.startswith(("actual_same_case_", "frozen_initial_answer_")):
                    del case[key]
            if variant == "B":
                case["actual_diagnostic_reference_answer"] = case.pop("actual_parent_answer")
        for key in ("skill_commit_policy", "adaptive_commit_objective", "admission_contract",
                    "admission_constraints", "rejected_candidate_feedback",
                    "public_TRAIN_edit_coordinates_before_proposed_shared_edits"):
            body.pop(key, None)
        body["teacher_evidence_contract"] = "bounded_seen_TRAIN_content_then_representation_diagnosis"
        body["diagnostic_contract"] = {
            "variant": variant, "fresh_reference_bank_sha256": MAIN_BANK,
            "reference_generated_in_this_decision_window": True,
            "current_A_library_has_not_been_executed": variant == "B",
            "no_A_or_B_candidate_outcomes_available": True,
            "UPDATE_existing_EV_blocks_only": True,
            "no_private_limit_metadata_or_TEST": True,
            "not_a_new_formal_learning_recipe": True}
        if variant == "B":
            body["bounded_emitted_evidence_contract"]["roles"] = ["actual_diagnostic_reference_answer"]
            body["prospective_actor_skill_messages"] = body.pop("actual_actor_skill_messages")
        self.bank = copy.deepcopy(self.parent)
        return body

    def propose(self):
        focus = [r for r in self.ev if r["case_id"] in self.ids]
        before = self._dispatch.native(lambda r: self.answer(r, self.parent, "fresh_parent12", "parent"), focus)
        self.grade(before)  # All12 saved before released targets enter either teacher.
        self.record("fresh_parent12.json", {"records": before, "metrics": metrics(before)})
        observations = {(r["case_id"], r["family"]): r for r in before}
        banks, contents = {}, []
        for variant in ("A", "B"):
            parent = self.parent if variant == "A" else banks["A"]
            schema = diagnosed_edit_schema(differential_schema(FAMILIES, parent, self.ids, guidance_schema=DIRECT_GUIDANCE), self.ids)
            if variant == "A":
                repair = {"type": "object", "additionalProperties": False, "properties": {
                    "skill_id": {"type": "string", "enum": [s["id"] for s in parent]},
                    "field": {"type": "string", "enum": list(FIELDS)},
                    "old_text": {"type": "string", "minLength": 1},
                    "replacement_text": {"type": "string", "minLength": 1},
                    "source_case_ids": {"type": "array", "minItems": 1, "items": {"type": "integer", "enum": sorted(self.ids)}}},
                    "required": ["skill_id", "field", "old_text", "replacement_text", "source_case_ids"]}
                schema["properties"]["clause_repairs"] = {"type": "array", "items": repair}
                schema["required"].append("clause_repairs")
                instruction = ("Make only minimal TRAIN-supported legal condition/content corrections. "
                    "Return clause_repairs quoting each unique old literal span and its replacement. "
                    "The delta bank must be EXACTLY the parent after those literal replacements; "
                    "retain every other character. No formatting rewrite, growth, or blanket spouse doubling.")
            else:
                instruction = ("A is the fixed corrected content, NOT an executed or successful bank. "
                    "The only actual outputs supplied are fresh ORIGINAL-parent diagnostic references. "
                    "Keep A's legal conditions, all real caps/citations, when and avoid_when unchanged. "
                    "Change only EV procedure representation into compact variable-binding steps and "
                    "a hypothetical native JSON worked illustration; no new legal repair, case answers or data table.")
            system = DIRECT_AUTHOR_SYSTEM.split("The body declares the fixed TRAIN commit policy.", 1)[0]
            system = system.replace("Compare the actual parent prediction, released target, and same-case controls.",
                "Compare the fresh diagnostic reference prediction with the released target; no same-case controls are supplied.")
            system = system.replace("Do not store case IDs, debtors, exact asset names or values, answer tables, output format tricks, or copied target sets in skills.",
                "Do not store case IDs, debtors, exact asset names, instance values, answer tables or copied target sets. A hypothetical native output illustration is allowed.")
            system += EXECUTION_AWARE_ADDITION + TASK_PROJECTION_TEACHING
            system = system.replace("NOOP is valid; the other scheduled task will still be taught.",
                                    "NOOP is valid; no additional quality retry is scheduled.")
            if variant == "B":
                system = system.replace("actual_actor_skill_messages", "prospective_actor_skill_messages")
            system += (" This is the predeclared bounded TRAIN diagnosis, not the formal stream's gate. "
                       "Use only UPDATE on original supplied EV blocks; the complete cap remains4096 tokens. " + instruction)
            body = self.teacher_packet(parent, observations, variant=variant)
            if variant == "B":
                body["fixed_content_repairs_from_A"] = contents
            value = self.teacher_call("variant_" + variant, system, body, schema)
            candidate = apply_differential_publication(parent, value["delta"], FAMILIES, self.ids, guidance_schema=DIRECT_GUIDANCE)
            if any(op["operation"] != "UPDATE" for op in value["delta"]["operations"]):
                raise ValueError("Only existing-block UPDATEs belong to this content/representation contrast")
            audit = validate_edit_diagnoses(parent, candidate, value["diagnoses"], self.ids)
            if variant == "A":
                if any(d["kind"] != "SKILL_DEFECT" for d in value["diagnoses"]):
                    raise ValueError("A diagnoses content defects, not an execution-example addition")
                contents = value["clause_repairs"]
                verify_clause_repairs(parent, candidate, contents, self.ids)
            else:
                a, b = {s["id"]: s for s in task_view(parent, "EV")}, {s["id"]: s for s in task_view(candidate, "EV")}
                if set(a) != set(b) or any({k: v for k, v in a[sid]["guidance"].items() if k != "procedure"}
                        != {k: v for k, v in b[sid]["guidance"].items() if k != "procedure"} for sid in a):
                    raise ValueError("B changed an EV trigger, exclusion, namespace or scope")
            tokens = self.validate_bank(parent, candidate)
            banks[variant] = candidate
            self.record("candidate_" + variant + ".json", {"bank": candidate, "bank_sha256": csha(candidate),
                "tokens": tokens, "diagnosis_audit": audit, "all128_EC_production_payloads_byte_identical": True})
        return {"status": "completed_proposals_awaiting_main_agent_semantic_review",
                "candidate_bank_sha256": {k: csha(v) for k, v in banks.items()},
                "candidate_outcomes_not_generated": True, "fresh_parent12": ref(self.out / "fresh_parent12.json")}

    @staticmethod
    def proposals():
        source = ROOT / "runs" / (GROUP + "_propose")
        if (source / "failure.json").exists():
            raise ValueError("The original proposals failed; no replacement candidates")
        done = read(source / "completion.json")
        if done["status"] != "completed_proposals_awaiting_main_agent_semantic_review":
            raise ValueError("The original two proposals did not complete; no replacement candidates")
        if len(read(source / "terminal_preservation.json")["paths"]) != 2:
            raise ValueError("Preserve paid proposals before candidate replay")
        review = read(source / "proposal_review.json")
        expected = ("A_only_supported_literal_content_repairs", "B_same_corrected_conditions_caps_citations",
                    "both_no_instance_answers", "B_native_illustration_is_hypothetical")
        banks = {v: read(source / ("candidate_" + v + ".json"))["bank"] for v in ("A", "B")}
        if (review["proposal_completion_sha256"] != sha(source / "completion.json")
                or review["candidate_bank_sha256"] != {k: csha(v) for k, v in banks.items()}
                or any(review["checks"].get(k) is not True for k in expected)
                or not review.get("rationale")):
            raise ValueError("Exact proposals require the main agent's substantive audit before replay")
        return source, banks

    def screen(self):
        source, banks = self.proposals()
        before = read(source / "fresh_parent12.json")["records"]
        if len(before) != 12 or {r["case_id"] for r in before} != self.ids:
            raise ValueError("Incomplete fresh parent12")
        # These are this window's new references, not main8's old cached answers.
        for record in before:
            raw = read(ROOT / record["raw_call_path"])
            row = next(r for r in self.ev if r["case_id"] == record["case_id"])
            messages, schema, _ = actor_payload(row, self.parent, grounded=True, direct_numeric=True, asset_references=True)
            q = raw["calls"][0]["request"]
            if (record["bank_sha256"] != MAIN_BANK or record["family"] != "EV"
                    or raw["transport_error"] is not None or len(raw["calls"]) != 1
                    or any(q[k] != self.cfg["generation"][k] for k in ("model", "temperature", "top_p", "top_k", "max_tokens", "seed"))
                    or q.get("chat_template_kwargs", {}).get("enable_thinking", True) is not True
                    or q["messages"] != messages or q["response_format"]["json_schema"]["schema"] != schema
                    or not str(ROOT / record["raw_call_path"]).startswith(str(source / "native/fresh_parent12/"))):
                raise ValueError("Fresh parent reference provenance changed")
            fingerprint = csha({"messages": messages, "schema": schema, "generation": self.cfg["generation"]})
            self.request_cache[fingerprint] = {"response": raw["response"], "raw_call_path": record["raw_call_path"]}
        rows = [r for r in self.ev if r["case_id"] in self.ids]
        def answer_row(row):
            order = ("A", "B") if row["case_id"] % 2 else ("B", "A")
            return {v: self.answer(row, banks[v], "candidate_screen12", v) for v in order}
        answers = self._dispatch.native(answer_row, rows)
        conditions = {v: self.grade([a[v] for a in answers]) for v in ("A", "B")}
        results = {}
        for variant, after in conditions.items():
            delta = gains(before, after)
            control = gains(subset(before, self.controls), subset(after, self.controls))
            results[variant] = {"gain_pp": delta, "correct_control_gain_pp": control,
                "eligible": min(delta.values()) >= 2 - 1e-10 and min(control.values()) >= -1 - 1e-10,
                "metrics": metrics(after), "paired": paired_effect(before, after), "records": after}
        eligible = [v for v in ("A", "B") if results[v]["eligible"]]
        winner = max(eligible, key=lambda v: (min(results[v]["gain_pp"].values()),
                     sum(results[v]["gain_pp"].values()), v == "A")) if eligible else None
        return {"status": "completed_screen_qualified" if winner else "closed_no_qualified_representation",
                "winner": winner, "fresh_parent12_source": ref(source / "fresh_parent12.json"),
                "results": results, "A_to_B_gain_pp": gains(conditions["A"], conditions["B"])}

    def confirm(self):
        _, banks = self.proposals()
        screen_path = ROOT / "runs" / (GROUP + "_screen") / "completion.json"
        screen = read(screen_path)
        if screen["status"] != "completed_screen_qualified" or screen["winner"] not in banks:
            raise ValueError("No qualified fixed12 candidate; close this branch without full replay")
        if len(read(screen_path.with_name("terminal_preservation.json"))["paths"]) != 2:
            raise ValueError("Preserve the completed screen before fresh full128 replay")
        winner = screen["winner"]
        if self.request_cache:
            raise ValueError("Full128 starts fresh, without screen/main8 response imports")
        def answer_row(row):
            order = ("parent", "candidate") if row["case_id"] % 2 else ("candidate", "parent")
            return {v: self.answer(row, self.parent if v == "parent" else banks[winner],
                                  "fresh_paired128", v) for v in order}
        answers = self._dispatch.native(answer_row, self.ev)
        before, after = [self.grade([a[v] for a in answers]) for v in ("parent", "candidate")]
        delta = gains(before, after)
        old = gains(subset(before, set(range(181, 197))), subset(after, set(range(181, 197))))
        later = gains(subset(before, set(range(197, 309))), subset(after, set(range(197, 309))))
        qualified = min(delta.values()) >= 2 - 1e-10 and min(old.values()) >= -1 - 1e-10 and min(later.values()) >= -1e-10
        self.validate_bank(self.parent, banks[winner])
        return {"status": "completed_eligible_for_new_formal_recipe" if qualified else "closed_full128_not_qualified",
            "winner": winner, "screen_completion": ref(screen_path), "gain_pp": delta,
            "old_B1_16_gain_pp": old, "subsequent112_gain_pp": later,
            "five_original_correct_controls_gain_pp": gains(subset(before, self.controls), subset(after, self.controls)),
            "parent_metrics": metrics(before), "candidate_metrics": metrics(after),
            "paired": paired_effect(before, after), "parent_records": before, "candidate_records": after,
            "per_original_batch_gain_pp": {str(n+1): gains(subset(before, set(range(181 + 16*n, 197 + 16*n))),
                subset(after, set(range(181 + 16*n, 197 + 16*n)))) for n in range(8)},
            "bank_not_an_equal_budget_formal_main_table_condition": True}

    def run(self):
        status = "failed"
        try:
            result = getattr(self, self.stage)()
            earlier = [read(ROOT / "runs" / (GROUP + "_" + s) / "completion.json")
                       for s in ("propose", "screen")[:("propose", "screen", "confirm").index(self.stage)]]
            linked_native = len(self.native) + sum(v["actual_native_calls"] for v in earlier)
            linked_teacher = len(self.teachers) + sum(v["actual_teacher_responses"] for v in earlier)
            if linked_native > 300 or linked_teacher > 2:
                raise ValueError("The combined diagnostic window exceeded its hard budget")
            result.update({"at": now(), "run_id": self.run_id, "diagnostic_stage": self.stage,
                "actual_native_calls": len(self.native), "actual_teacher_responses": len(self.teachers),
                "actual_teacher_attempts": self.teacher_attempts, "linked_native_calls": linked_native,
                "linked_teacher_responses": linked_teacher,
                "linked_teacher_attempts": self.teacher_attempts + sum(v["actual_teacher_attempts"] for v in earlier),
                "native_prompt_tokens": sum(v["response"]["prompt_tokens"] for v in self.native if v["response"]),
                "native_completion_tokens": sum(v["response"]["completion_tokens"] for v in self.native if v["response"]),
                "teacher_reported_usage": {k: sum(t["invocation"]["usage"].get(k, 0) for t in self.teachers)
                    for k in ("input_tokens", "cached_input_tokens", "output_tokens", "reasoning_output_tokens")},
                "no_TEST_or_formal_learning_success_claim": True})
            self.check()
            self.record("completion.json", result)
            status = result["status"]
            print(json.dumps({k: result[k] for k in ("status", "run_id", "actual_native_calls", "actual_teacher_responses")}), flush=True)
        except BaseException as exc:
            self.record("failure.json", {"at": now(), "error": repr(exc), "traceback": traceback.format_exc(),
                "actual_native_calls": len(self.native), "actual_teacher_responses": len(self.teachers),
                "actual_teacher_attempts": self.teacher_attempts, "no_quality_retry_or_fallback": True})
            raise
        finally:
            self.progress("terminal", state=status)
            files = [str(p.relative_to(ROOT)) for p in self.out.rglob("*") if p.is_file() and "/cache/" not in str(p)]
            self.record("terminal_preservation.json", preserve(self.run_id, "actual-terminal", files))


def after_strict(config):
    """A finite operational queue, not a retry, new learner or admission rule."""
    cfg = read(config)
    if cfg["run_id"] != GROUP + "_propose" or cfg["diagnostic_stage"] != "propose":
        raise ValueError("Only the declared proposal stage may be queued")
    try:
        validate_config(config)
    except StrictStillLive:
        pass
    if config.with_suffix(".frozen.json").exists() or (ROOT / "runs" / cfg["run_id"]).exists():
        raise FileExistsError("Never relaunch or replace an existing diagnostic stage")
    bindings = {str(p): sha(p) for p in (config, Path(__file__).resolve(), ROOT / cfg["protocol"], ROOT / PLAN)}
    guard = SimpleNamespace(cfg=cfg, bindings=bindings, stop=False)
    intent = QUEUE.with_suffix(".intent.json")
    RunStore.immutable_json(intent, {"at": now(), "config": ref(config), "driver": ref(Path(__file__).resolve()),
        "bindings": bindings, "wait_for_strict_complete_and_dual_preserved": True,
        "maximum_wait_seconds": 43200, "no_API_calls_while_waiting": True,
        "proposal_only_max_native12_teacher2_then_exit_for_semantic_review": True})
    startup_files = [str(p.relative_to(ROOT)) for p in (intent, config, Path(__file__).resolve(), ROOT / cfg["protocol"], ROOT / PLAN)]
    RunStore.immutable_json(QUEUE.with_suffix(".start_preservation.json"), preserve(GROUP, "queued-propose-intent", startup_files))
    print(json.dumps({"at": now(), "state": "waiting_for_original_strict_control",
                      "intent": ref(intent), "no_diagnostic_calls_yet": True}), flush=True)
    deadline = time.monotonic() + 43200
    try:
        while True:
            Online.check(guard)  # Existing frozen model/source identity guard; no HTTP.
            try:
                strict_finished()
            except StrictStillLive:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Finite queue expired; inspect control, do not restart it")
                time.sleep(30)  # Background service only, never a blocking assistant wait.
                continue
            break
        print(json.dumps({"at": now(), "state": "strict_complete_preserved_freezing_then_proposing"}), flush=True)
        for action in ("freeze", "run"):
            subprocess.run([sys.executable, "-u", "-m", "experiments.openexempt_ev_representation",
                            action, str(config)], cwd=ROOT, check=True)
        done = ROOT / "runs" / cfg["run_id"] / "completion.json"
        result = {"at": now(), "state": "completed_proposals_no_candidate_replay",
                  "completion": ref(done), "status": read(done)["status"]}
    except BaseException as exc:
        RunStore.immutable_json(QUEUE.with_suffix(".result.json"), {"at": now(), "state": "failed_no_automatic_restart",
            "error": repr(exc), "traceback": traceback.format_exc()})
        raise
    else:
        RunStore.immutable_json(QUEUE.with_suffix(".result.json"), result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("freeze", "run", "after-strict"))
    parser.add_argument("config", type=Path)
    args = parser.parse_args()
    config = args.config.resolve()
    if args.action == "after-strict":
        after_strict(config)
        return
    cfg, _ = validate_config(config)
    if args.action == "freeze":
        extra = [Path(__file__).resolve(), ROOT / PLAN, ROOT / MAIN_CONFIG,
                 (ROOT / MAIN_CONFIG).with_suffix(".frozen.json"), ROOT / "runs" / MAIN / "completion.json",
                 ROOT / "runs" / STRICT / "completion.json", ROOT / "runs" / STRICT / "terminal_preservation.json"]
        extra += list((ROOT / "runs" / MAIN / "batches").glob("*_prequential_records.json"))
        extra += [p for p in (QUEUE.with_suffix(".intent.json"), QUEUE.with_suffix(".start_preservation.json")) if p.exists()]
        for phase in ("propose", "screen")[:("propose", "screen", "confirm").index(cfg["diagnostic_stage"])]:
            extra += [p for p in (ROOT / "runs" / (GROUP + "_" + phase)).rglob("*")
                      if p.is_file() and "/cache/" not in str(p) and p.name != "progress.json"]
        freeze(config, additional_sources=extra)
    else:
        with (ROOT / "artifacts/openexempt_training.lock").open("a+") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            RepresentationDiagnosis(config).run()


if __name__ == "__main__":
    main()
